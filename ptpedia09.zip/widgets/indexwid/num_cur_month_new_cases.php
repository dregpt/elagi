<tr>
	<td>New cases:</td>
	<td>
		<?php
				if(is_logged_in()){
					echo num_month_cases($cn,date("Y-m",time()));
				}				
		?>
	</td>
</tr>
