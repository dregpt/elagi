
	<div class="container">
		
		<div class="mainscreen">
		
			<div class="screenmenu">
			
			</div>
			<div class="screen">				
				<div class="leftscreen">Left screen
				
                    <div class="ajaxdata"></div>
                    <button id="ajax" >show ajax data</button>
					
					
				</div>
				<div class="rightscreen">Right screen</div>
			</div>
		</div>
		<div class="sidebar">
			<table>
				
				<?php
				
					include('widgets/indexwid/usernamewid.php');
					include('widgets/indexwid/rulenamewid.php');
				
				?>

			</table>
		</div>
	</div>
</div>


						
