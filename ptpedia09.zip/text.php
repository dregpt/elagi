
<?php
include("core/init.php");






echo "<input type='text' value='".$user_data['frst_nm']." ".$user_data['lst_nm']."'> ";

?>