// // JavaScript Document
//
// // import ElagiSession from "./classes";
//
//
// const ptses= new ElagiSession(
//     "Physical Therapy",
//     "PT",
//     90,
//     120
// )
//
// const showText= function (){
//     var target= document.querySelector(".ajaxdata")
//     var ajax = new XMLHttpRequest();
//     ajax.open("GET", "text.php",true);
//     ajax.onreadystatechange= function(){
//         console.log("ReadyStatus:"+ajax.readyState);
//         if(ajax.readyState==2){
//             target.innerHTML="Loading ..."
//         }
//         if(ajax.readyState==4 && ajax.status==200){
//             target.innerHTML= ajax.responseText
//         }
//     }
//     ajax.send();
// }
//
// //const btm=document.querySelector("#ajax")
// //btm.addEventListener("click",showText);
//
//
// // // to get waiting session start time:
// // var ses_start_time=document.querySelector('.ses_start_time').value;
// // var ses_end_time=document.querySelector('.ses_end_time').value;
// // var now = new Date();
// // var current_hour= now.getTime();
// // console.log("Start hour:"+ses_start_time);
// // console.log("End hour:"+ses_end_time);
// // console.log(current_hour);
// //
// // ses_rec_stat=document.querySelectorAll('.rec_stat')//.classList.add('rec_btm');
// //
// // function activate_ses_record(element){
// //     if(current_hour>=ses_start_time && current_hour<=ses_end_time){
// //     element.classList.add('rec_btm');
// //     }
// // }
// //
// // ses_rec_stat.forEach(element=>activate_ses_record(element));
// //
//
//
//
//
//
//
//
//
//
