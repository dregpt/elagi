<?php

date_default_timezone_set('Africa/Cairo');
session_start();
//ini_set('session.cookie_lifetime', '1200');
//ini_set('display_errors','off');
//error_reporting(E_ALL);
//error_reporting(0);
// data base connction function:




// Required functions files:

require_once('cn.php');
require_once('dbfncs.php');
require_once('fncts.php');
require_once('funcdate.php');
require_once('funcsrv.php');
require_once('funcses.php');
require_once('funcpay.php');

// Required classes files in classes directory:
require_once("classes/user.class.php");

//connect db to calsses:
$cn_ob=db_connect();
User::set_database($cn_ob);

//User data:
if(is_logged_in()===true){
	$session_user_id=$_SESSION['user_id'];
	$user_data = user_data($session_user_id,$cn,'usr_id', 'eml', 'pswrd', 'frst_nm', 'lst_nm', 'actv', 'prv');
	
	if(user_is_active($cn,$user_data['eml'])===false){
		session_destroy();
		header('location:lgn.php');
	}
}


if( $_SERVER[ 'SERVER_NAME' ] != 'localhost' ){
   @ mail();
}


//Messages:
$message= array();

//echo substr($_SERVER['REQUEST_URI'],1);

//echo $user_data['usr_id'];
if (isset($user_data)===true){
if($user_data['usr_id']==325){ // run functions for developer user (Ibrahim salem)
    //$admins_emls=get_emails_inarray($cn, 9);
   // $cases_emls=get_emails_inarray($cn, 7);
   // $ses_day=date("Y-m-d",time());



//   $cas_id= 261;
//    $srv_cd="PT";
//   $month="2021-08";

    
  //echo  number_of_month_sessions($cn, $month);

  //echo"<pre>"; print_r($admins_emls); echo"</pre>";

   // $test= service_price($cn,$srv_cd,$cas_id);
  // echo"<pre>"; print_r($_SESSION['cases_dues']); echo"</pre>";
    //echo $_SESSION['cases_dues'];
  //  reg_rec_ses_stat_op($cn, 5);

//echo date("Y-m", strtotime("$month -1 month"));

  // echo  case_has_pay_due($cn,158);
   // total_ses_costs($cn,$cas_id,$month);
   //current_month_payment_dues($cn);

//$varid="cas_id158232";
//echo substr($varid, 6,6);

}}

$args['frst_nm']='Ibrahim';
$args['pswrd']='pass';
$args['pswrd2']='pass';
$args['lst_nm']='Salem';
$args['dob'] ='';
$args['eml'] ='iuhhui@uihiuh';
$args['ph1'] ='878789';
$args['ph2'] ='877897';
$args['address'] ='Moqattam';
$args['usr_catg'] ='PT';
$args['actv'] ='1';
$args['prtct'] ='0';
$args['submitter'] ='ibrahim';
$args['submit_timestamp'] ='time';

$therapist = new User($args);

//echo $therapist->update();

//echo date("Y-m",strtotime("first day of +1 month"));











?>