<?php

class User{
    static protected $cn_ob;
    static public function set_database($cn_ob){
        self::$cn_ob=$cn_ob;
    }

    static  protected $db_columns=['frst_nm', 'lst_nm', 'dob', 'pswrd', 'eml', 'ph1', 'ph2', 'address', 'usr_catg',
        'actv', 'prtct', 'submitter', 'submit_timestamp'];

    static public function find_by_sql($sql){
        $result= self::$cn_ob->query($sql);
        if(!$result){
            exit("Database query failed!");
        }
        $object_array=[];
        while($record = $result->fetch_assoc()){
            $object_array[]=self::instantiate($record);
        }
        return $object_array;
    }

    static public function find_all(){
        $sql="select * from users";
        return self::find_by_sql($sql);
    }

    static public function find_user_by_id($usr_id){
        $sql="select * from users";
        $sql.=" where usr_id=".self::$cn_ob->escape_string($usr_id)." ";
       $obj_array= self::find_by_sql($sql);
       if(!empty($obj_array)){
       //    return $obj_array;
           return    array_shift($obj_array);
       }else{
           return false;
       }
    }

    static public function instantiate($record){
        $object= new self;
        foreach ($record as $property => $value){
            if(property_exists($object,$property)){
                $object->$property=$value;
            }
        }
        return $object;
    }

    protected function create(){
        $attributes= $this->sanitized_attributes();
        $sql="insert into users (";
        $sql.=join(", ", array_keys($attributes));
        $sql.=" ) values ( '";
        $sql.=join("', '", array_values($attributes));
        $sql.="')";
        $result= self::$cn_ob->query($sql);
       // return $sql;
        if($result){
            $this->usr_id= self::$cn_ob->insert_id;
        }
        return $result;
    }

    protected function  update(){
        $attributes=$this->sanitized_attributes();
        foreach ($attributes as $key=> $value){
            $att_pairs[]="{$key}='{$value}'";
        }
        $sql="update users set ";
        $sql.=join(", ", $att_pairs);
        $sql.="where usr_id = ".self::$cn_ob->escape_string($this->usr_id)." ";
        $result=self::$cn_ob->query($sql);
        return $result;
    }

    public function save(){
        if(isset($this->usr_id)){
           return  $this->update();
        }else{
           return  $this->create();
        }
    }

    public function merge_attributes($args=[]){
        foreach ($args as $key => $value){
            if(property_exists($this, $key) && !is_null($value)){
               $this->$key=$value;
            }
        }
    }
    public function attributes(){
        $attributes=[];
        foreach (self::$db_columns as $column){
            if($column==="usr_id"){continue;}
            $attributes[$column]= $this->$column;
        }
        return $attributes;
    }

    protected function sanitized_attributes(){
        $sanitized=[];
        foreach ($this->attributes() as $key => $value){
            $sanitized[$key]= self::$cn_ob->escape_string($value);
        }
        return $sanitized;
    }


    public $usr_id;
    public $frst_nm;
    public $scnd_nm;
    public $thrd_nm;
    public $lst_nm;
    public $dob;
    public $eml;
    public $ph1;
    public $ph2;
    public $address;

    public function __construct($args=[]){
        $this->frst_nm         =$args['frst_nm'] ?? '';
        $this->lst_nm          =$args['lst_nm'] ?? '';
        $this->dob             =$args['dob'] ?? '';
        $this->eml             =$args['eml'] ?? '';
        $this->ph1             =$args['ph1'] ?? '';
        $this->ph2             =$args['ph2'] ?? '';
        $this->pswrd           =$args['pswrd'] ?? '';
        $this->usr_catg        =$args['usr_catg'] ?? '';
        $this->actv            =$args['actv'] ?? '';
        $this->prtct           =$args['prtct'] ?? '';
        $this->submitter       =$args['submitter'] ?? '';
        $this->submit_timestamp=$args['submit_timestamp'] ?? '';
    }

    public function full_name(){
        echo"{$this->frst_nm} {$this->scnd_nm} {$this->thrd_nm} {$this->lst_nm}";
    }
}


























?>
