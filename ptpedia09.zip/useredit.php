<?php 
include("core/init.php");
include("head.php");

If(is_logged_in()===false){
	header('location:lgn.php');
}	
?>


<?php include("includes/menues/admin_screenmenu.php");

if(isset($_GET['usr_id'])){
    $usr_id=$_GET['usr_id']?? false;
}elseif(isset($_POST['eml'])){
    $usr_id=get_user_id_from_email($cn,$_POST['eml']);
}

if(!empty($usr_id)) {
    $user = User::find_user_by_id($usr_id);


    if ((empty($_POST) === false) && (empty($message) === true)) {
        $register_data = array(
            "frst_nm" => uc_frst_char_words($_POST['frst_nm']),
            "lst_nm" => uc_frst_char_words($_POST['lst_nm']),
            "dob" => strtotime($_POST['dob']),
            "address" => $_POST['address'],
            "eml" => $_POST['eml'],
            "pswrd" => $_POST['pswrd'],
            "ph1" => $_POST['ph1'],
            "ph2" => $_POST['ph2'],
            "usr_catg" => $_POST['usr_catg'],
            "actv" => $_POST['actv'],
            "prtct" => $_POST['prtct'],
            "submitter" => $_POST['submitter'],
            "submit_timestamp" => $_POST['submit_timestamp']
        );
        $first_name = $register_data['frst_nm'];
        $last_name = $register_data['lst_nm'];
        $user->merge_attributes($register_data);
        $result = $user->save();
        if ($result === true) {
            $message[] = "User (" . $first_name . " " . $last_name . ") is successfully updated!";
        }
    }



?>

			<div class="screen">
				<form action="useredit.php" method="post">
                    <div class="screencontainer">Edit user profile for: <spam class="yellowfont"><?php echo $user->full_name(); ?></spam>

					<?php  echo messages($message); ?>
					<div class="leftscreen">
						<div class="discreen">
							<div class="formcolumn">
								<fieldset>
								<legend>Personal Information</legend>
									<label> First name:</label><br>
									<input type="text" class="txtbx" name="frst_nm" required maxlength="20" value="<?php echo $user->frst_nm; ?>"><br>
									<label> Last name:</label><br>
									<input type="text" class="txtbx" name="lst_nm" required maxlength="20" value="<?php echo $user->lst_nm; ?>"><br>
									<label> Date of birth (DOB):</label><br>
									<input type="date" class="txtbx" name="dob" value="<?php echo date('Y-m-d',(int)($user->dob)); ?>"><br>
								</fieldset>
								<fieldset>
								<legend>Contact information</legend>
									<label> Address:</label><br>
									<input type="text" class="txtbx" name="address" maxlength="300" value="<?php echo $user->address; ?>"><br>
									<label> Email:</label><br>
									<input type="email" class="txtbx" name="eml" required maxlength="100" value="<?php echo $user->eml; ?>"><br>
									<label>Password:</label><br>
									<input type="password" class="txtbx" name="pswrd" required maxlength="30" value="<?php echo $user->pswrd; ?>"><br>
									<label> Retype password:</label><br>
									<input type="password" class="txtbx" name="pswrd2" required maxlength="30" value="<?php echo $user->pswrd; ?>"><br>
									<label> Phone number 1:</label><br>
									<input type="tel" class="txtbx" name="ph1" placeholder="" pattern="[0-9]{11}" required maxlength="11" value="<?php echo $user->ph1; ?>"><br>
									<label> Phone number 2:</label><br>
									<input type="tel" class="txtbx" name="ph2" placeholder="" pattern="[0-9]{11}" maxlength="11" value="<?php echo $user->ph2; ?>"><br>

								</fieldset>
							</div>
							<div class="formcolumn">
								<fieldset>
								<legend>Index data</legend>
									<label> First date of work (DOW):</label><br>
									<input type="date" class="txtbx" name="dow"><br>
									<label> User category:</label><br>
									<select class="txtbx" name="usr_catg" required>
									  <option disabled selected value value=""> -- select user category -- </option>
									  <?php
										 get_user_categories_opt($cn,$user->usr_id);
									  ?>
									</select><br>
								</fieldset>
<!--								<fieldset>-->
<!--								<legend>Sallary setting</legend>-->
<!--									<label> <input type="hidden" name="fxd_sal" value="0"> <input type="checkbox" name="fxd_sal"  value="1" >Fixed sallary:</label><br>-->
<!--									<input type="number"  class="txtbx" name="sal" step=1><br>-->
<!--									<label> <input type="hidden" name="rat_sal" value="0"> <input type="checkbox" name="rat_sal"  value="1"> Rate category:</label><br>-->
<!--									<input type="hidden" name="rat_catg" value="0"><select class="txtbx" name="rat_catg">-->
<!--									  <option disabled selected value value=""> -- select rate category -- </option>-->
<!--									  --><?php
//										 get_rat_categories_opt($cn);
//									  ?>
<!--									</select><br>-->
<!--									<label> Rate by:</label><br><input type="hidden" name="rat_by" value="0">-->
<!--									<input type="radio" name="rat_by" class="txtbx" value="1">Hour<br>-->
<!--									<input type="radio" name="rat_by" class="txtbx" value="2">Session-->
<!--								</fieldset>-->
								<fieldset>
								<legend>Profile setting:</legend>
									<input type="hidden" name="actv" value="0"><input type="checkbox" name="actv"
                                        <?php if($user->actv==1){echo "value='1' checked";}  ?> > Active user<br>
									<input type="hidden" name="prtct" value="0"><input type="checkbox" name="prtct"
                                        <?php if($user->prtct==1){echo "value='1' checked";}  ?>> Protected user
								</fieldset>
							</div>
							<div class="formcolumn">
                                <input type="hidden" value="<?php echo $user_data['usr_id']; ?>" name="submitter">
                                <input type="hidden" value="<?php echo time(); ?>" name="submit_timestamp">
								<input type="button" class="buttom1" onClick="window.location.href='useredit.php'" value="Refresh">
								<input type="button" class="buttom1" onclick="window.location.href='useradd.php'" value="New">
								<input type="submit" class="buttom1" value="Save">
							</div>
						</div>
					</div>
				</div>
				</form>
                <?php  } ?>
				<div class="rightscreen">All users: <br>
					<div class="rightscreendata">
						<?php
							get_all_users_names($cn);
					 	?>
					</div>
				</div>	
		</div>
		</div>
		<div class="sidebar">
			<table>
				<?php
					include('widgets/indexwid/nouserswid.php');
				?>
			</table>
		</div>
	</div>
</div>












<?php include("foot.php"); ?>