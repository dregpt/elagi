		<div class="footer" > <small >Copyright &copy; 2021 Elagi, All rights reserved</small></div>
	</div>

</body>




</html>