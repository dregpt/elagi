<?php 
include("core/init.php");
include("head.php"); 
?>

		



<?php include("includes/menues/reports_screenmenu.php"); ?>

			<div class="screen">
				<div class="leftscreen">Case reports</div>
				<div class="rightscreen">Right screen</div>
			</div>
		</div>
		<div class="sidebar">sidebar</div>
	</div>
</div>












<?php include("foot.php"); ?>