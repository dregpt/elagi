<?php 
include("core/init.php");
include("head.php");


If(is_logged_in()===false){
	header('location:lgn.php');
}
?>


<?php include("includes/menues/cases_screenmenu.php"); 

if(empty($_POST)===false){
	
	if(empty($message)===true){
		if(email_is_found($cn,$_POST['eml'])===true){
			$email=$_POST['eml'];
			$message[]= "This email is already registered: (".$email.")";
		}
			
		if((phon_is_found($cn,$_POST['ph1'])===true)||(phon_is_found($cn,$_POST['ph2'])===true)){
			$phon1 = $_POST['ph1'];
			$phon2 = $_POST['ph2'];
			$message[]= "The phone number is already registered for another user ";
		}
		
		if(preg_match("/\\s/",$_POST['frst_nm'])==true){
			$frst_nam=ucfirst($_POST['frst_nm']);
			$message[]= "First name is only one name and mustn't contain any spaces: (".$frst_nam.")";
		}
		if(preg_match("/\\s/",$_POST['scnd_nm'])==true){
			$frst_nam=ucfirst($_POST['scnd_nm']);
			$message[]= "Second name is only one name and mustn't contain any spaces: (".$frst_nam.")";
		}
		if(preg_match("/\\s/",$_POST['thrd_nm'])==true){
			$frst_nam=ucfirst($_POST['thrd_nm']);
			$message[]= "Third name is only one name and mustn't contain any spaces: (".$frst_nam.")";
		}
		
		if(preg_match("/\\s/",$_POST['lst_nm'])==true){
			$lst_nam=ucfirst($_POST['lst_nm']);
			$message[]= "Last name is only one name and mustn't contain any spaces: (".$lst_nam.")";
		}
		
		if(fullname_is_found($cn,$_POST['frst_nm'],$_POST['scnd_nm'],$_POST['thrd_nm'],$_POST['lst_nm'])===true){
			$message[]= "This full name (".$_POST['frst_nm']." ".$_POST['scnd_nm']." ".$_POST['thrd_nm']." ".$_POST['lst_nm'].") is previously registered";
		}
        
        if(file_id_is_found($cn,$_POST['file_id'])===true){
			$message[]= "This file id number is already in use!";
        }
	}
}

if((empty($_POST)===false) && (empty($message)===true)){
			$register_data=array(
			"frst_nm"   => uc_frst_char_words($_POST['frst_nm']),
			"scnd_nm"   => uc_frst_char_words($_POST['scnd_nm']),
			"thrd_nm"   => uc_frst_char_words($_POST['thrd_nm']),
			"lst_nm"    => uc_frst_char_words($_POST['lst_nm']),
			"fthr_wrk"  => $_POST['fthr_wrk'],
			"mthr_nm"   => uc_frst_char_words($_POST['mthr_nm']),
			"mthr_wrk"  => $_POST['mthr_wrk'],
			"address"   => $_POST['address'],
			"dob"       => strtotime($_POST['dob']),
			"eml"       => $_POST['eml'],
			"ph1"       => $_POST['ph1'],
			"ph2"       => $_POST['ph2'],
			"file_id"   => $_POST['file_id'],
			"referral"  => $_POST['referral'],
			"dof"       => strtotime($_POST['dof']),
			"usr_catg"  => $_POST['usr_catg'],
			"submitter" => $_POST['submitter'],
			"submit_timestamp" => $_POST['submit_timestamp']
		);
	
		add_user($cn,$register_data);
												$first_name=$register_data['frst_nm'];
												$last_name = $register_data['lst_nm'];

	//echo "<pre>"; print_r($_POST); echo "</pre>";
		$message[]="Case (".$first_name." ".$last_name.") is successfully added!";
}


if(isset($_GET['casedeleted'])===true){
	$message[] = "Case is deleted!";
}

?>

			<div class="screen">
				<form action="caseadd.php" method="post">
				<div class="screencontainer">Add new case: <br>
				<?php //test:	
				//echo uc_frst_char_words("ibRAHIm saLeM");
				?>
					
					<?php  echo messages($message); ?>
					<div class="leftscreen">
						<div class="discreen">
							<div class="formcolumn">
								<fieldset>
								<legend>Personal Information</legend>
									<label> Case's first name:</label><br>
									<input type="text" class="txtbx" name="frst_nm" <?php echo isset($_POST['frst_nm'])? "value='".$_POST['frst_nm']."'":''; ?> placeholder="" required maxlength="15"><br>
									<label> Case's 2nd name:</label><br>
									<input type="text" class="txtbx" name="scnd_nm" <?php echo isset($_POST['scnd_nm'])? "value='".$_POST['scnd_nm']."'":''; ?> placeholder="" required maxlength="15"><br>
									<label> Case's 3rd name:</label><br>
									<input type="text" class="txtbx" name="thrd_nm" <?php echo isset($_POST['thrd_nm'])? "value='".$_POST['thrd_nm']."'":''; ?> required maxlength="15"><br>
									<label> Case's 4th name:</label><br>
									<input type="text" class="txtbx" name="lst_nm" <?php echo isset($_POST['lst_nm'])? "value='".$_POST['lst_nm']."'":''; ?> required maxlength="15"><br>
									<label> Father's work:</label><br>
									<input type="text" class="txtbx" name="fthr_wrk" <?php echo isset($_POST['fthr_wrk'])? "value='".$_POST['fthr_wrk']."'":''; ?> required maxlength="200"><br>
									<label> Mother's name:</label><br>
									<input type="text" class="txtbx" name="mthr_nm" <?php echo isset($_POST['mthr_nm'])? "value='".$_POST['mthr_nm']."'":''; ?> required maxlength="80"><br>
									<label> Mother's work:</label><br>
									<input type="text" class="txtbx" name="mthr_wrk" <?php echo isset($_POST['mthr_wrk'])? "value='".$_POST['mthr_wrk']."'":''; ?> required maxlength="200"><br>	
								</fieldset>
								<fieldset>
								<legend>Contact information</legend>
									<label> Address:</label><br>
									<input type="text" class="txtbx" name="address" <?php echo isset($_POST['address'])? "value='".$_POST['address']."'":''; ?> maxlength="200"><br>
									<label> Email:</label><br>
									<input type="email" class="txtbx" name="eml" <?php echo isset($_POST['eml'])? "value='".$_POST['eml']."'":''; ?> maxlength="200"><br>
									<label> Phone number 1:</label><br>
									<input type="tel" class="txtbx" name="ph1" <?php echo isset($_POST['ph1'])? "value='".$_POST['ph1']."'":''; ?> placeholder="" pattern="[0-9]{11}" maxlength="11" required><br>
									<label> Phone number 2:</label><br>
									<input type="tel" class="txtbx" name="ph2" <?php echo isset($_POST['ph2'])? "value='".$_POST['ph2']."'":''; ?> placeholder="" pattern="[0-9]{11}" maxlength="11"><br>

								</fieldset>
							</div>
							<div class="formcolumn">
								<fieldset>
								<legend>Index data</legend>
									<label> File ID:</label><br>
									<input type="tel" class="txtbx" name="file_id" <?php echo isset($_POST['file_id'])? "value='".$_POST['file_id']."'":''; ?> placeholder="17000" pattern="[0-9]{5}" maxlength="5" required><br>
									<label> Date of first evaluation (DOF):</label><br>
									<input type="date" class="txtbx" name="dof" <?php echo isset($_POST['dof'])? "value='".$_POST['dof']."'":''; ?> required><br>
									<label> Date of birth (DOB):</label><br>
									<input type="date" class="txtbx" name="dob" <?php echo isset($_POST['dob'])? "value='".$_POST['dob']."'":''; ?> required><br>
									<label> Referral:</label><br>
									<input type="text" class="txtbx" name="referral" <?php echo isset($_POST['referral'])? "value='".$_POST['referral']."'":''; ?> ><br>
								</fieldset>
							</div>
							<div class="formcolumn">
								<input type="hidden" value="7" name="usr_catg">
								<input type="hidden" value="<?php echo time();?>" name="submit_timestamp">
								<input type="hidden" value="<?php echo $user_data['usr_id']; ?>" name="submitter">
								<input type="button" class="buttom1" onClick="window.location.reload()" value="Refresh">
								<input type="button" class="buttom1" onclick="window.location.href='caseadd.php?caseedit'" value="New">
								<input type="submit" class="buttom1" value="Add case">
								<input type="button" class="buttom1" onclick="window.location.href='caseedit.php?caseedit'" value="Edit case">							
							</div>
						</div>
					</div>
				</div>
				</form>
				<div class="rightscreen">Recently added cases: <br>
					<div class="rightscreendata">
						<?php
							get_recent_added_cases_list($cn);
						?>
					</div>
				</div>	
		</div>
		</div>
		<div class="sidebar">
			<table>
				<?php
					include('widgets/indexwid/nocaseswid.php');
				?>
			</table>
		</div>
	</div>
</div>












<?php include("foot.php"); ?>