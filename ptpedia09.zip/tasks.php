<!-- Form for sessions status-->
<!-- option to change colors fro every session status -->
- administration >Form to change default services prices and fines
<!-- change delete and edit icons in cases list -->
- change delete and edit icons in therapists list
- change delete icaons in users list
- add edit form for users list
<!-- case payments report __>
<!-- Set session prices for every case-->
- case session report > according to session status.
- therapists > therapist ponus and penalty from.
- delete option should be approved by admins.
- number of taken sessions / default.
<!-- site menue.-->
<!-- payment list for admins -->
- expenses form.
- Notification on session delay
- Notification on payment delay
<!-- acc table -->
- accounting list for all cases
- case auto deactivation system
<!-- make session setting more easier!-->
<!-- review recording of excused and absence rebooked-->
- Dashboard> notification system on the site
- Administration> notification setting
- messaging system
- report > report sessions and hours for every therapist
<!--- decrease site header area -->
- count session status wedgits
- dashboard > upcoming excuses
- dashboard > previous excuses
- report > excuses and absence list
- report > month revenue
- report > month revenue
- report > month sessions

- report> excuses and abcence month list
- notification system
























