	<div class="container">
		<div class="mainscreen">
			<div class="screenmenu">
				<a href="useredit.php?admin&useredit" id="<?php echo activate_tabe($_GET['useredit'],"screenmenuebtm") ?>">Manage users</a>
				<a href="usercatgadd.php?admin&usercatgadd" id="<?php echo activate_tabe($_GET['usercatgadd'],"screenmenuebtm") ?>">User categories</a>
				<a href="srvadd.php?admin&srvadd" id="<?php echo activate_tabe($_GET['srvadd'],"screenmenuebtm") ?>">Services</a>
				<!--<a href="admin.php?admin&adm" id="<?php echo activate_tabe($_GET['adm'],"screenmenuebtm") ?>">Setting</a> -->
			</div>