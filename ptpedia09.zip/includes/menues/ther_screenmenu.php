	<div class="container">
		<div class="mainscreen">
			<div class="screenmenu">
				<a href="thrpedit.php?thrpedit&thrped" id="<?php echo activate_tabe($_GET['thrped'],"screenmenuebtm") ?>">Manage therapists</a>
				<!-- <a href="#" class="salaryset">Salary setting</a> -->
				<a href="ther_sessions.php?thrpedit&ther_sessions" id="<?php echo activate_tabe($_GET['ther_sessions'],"screenmenuebtm") ?>">Sessions</a>
				<a href="ther_stat.php?thrpedit&ther_stat" id="<?php echo activate_tabe($_GET['ther_stat'],"screenmenuebtm") ?>">Status</a>
			</div>


	